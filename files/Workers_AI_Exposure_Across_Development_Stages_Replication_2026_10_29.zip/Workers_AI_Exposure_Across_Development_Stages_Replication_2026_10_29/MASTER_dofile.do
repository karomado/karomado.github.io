
/*
*MASTER DO-FILE -- Lewandowski et al. (2025)
*Run this file to reproduce all outputs. Do-files must be run in the order below.

1. 1_microdata_regression_analysis.do:
		-TableS6.xls — Table S6 from Supplementary Materials (SM). 
			Table S6. The correlates of individual AI exposures (OLS estimations)
		-Figure_S6_data.xls — Figure S6 from SM. Excel file contains Figure S6.
			Figure S6. Estimated relationship between computer use and AI exposure, for all workers and by occupational group
		-Table_S7_and_Figure_2.xlsx — Table S7 from SM. 
			Table S7. The decomposition of the cross-country variance in country-specific AI exposure (in % of variance)	
		-Figure_S7_8_data.xls — country-level data for Figures S7 and S8. 
			Figure S7. Convergence of average AI exposure across developed countries with two cycles of detailed PIAAC data
			Figure S8. Regression-weighted contributions to changes in country AI exposure over time, selected countries with multiple cycles of PIAAC data

2. 1_5_descriptive_statistics.do:
		-Figure_S3.png / .emf
			Figure S3. The comparison of the average Felten et al. (2021) and PIAAC/STEP-based AI exposures at the country level
		- Figure_S4.png / .emf
			Figure S4. The comparison of the average Felten et al. (2021) and the PIAAC-based US AI exposures at the country level
		- Figure_S5.xls — country-level AI exposure and shift-share decomposition data for Figure S5 from SM. Excel file contains Figure S5.
			Figure S5. Shift-share decomposition of the differences in AI exposure by country

3. 1_6_Figure_S1_Tables10_15.do:
		- Tables10_15.xls — Tables S10-S15 from SM section 6. Estimated question weights for O*NET abilities
			Table S10-S15. Estimation of the PIAAC question weights for O*NET abilities
		- Figure_S1.png / .emf
			Figure S1. The correlation between AIOE calculated for the US with O*NET abilities and with PIAAC survey data
		- Figure_S2.png / .emf
			Figure S2. The correlation between occupational exposure to GPTs (8) and task-based exposure to AI calculated with PIAAC survey data for the US

4. 1_7_Tables_S16_S21.do:
		- Tables_S16_S21.xls — Tables S16-S21 from SM section 6. Estimated question weights for O*NET abilities
			Table S16-S21. Estimation of the STEP question weights for O*NET abilities 

5. 2_out_of_sample_predictions.do:
		- Table_S9.xls — Table S9 from SM. 
			Table S9. Estimation of the out-of-sample prediction models
		- Figure_S9/isco_*.gph, .png, .emf — one graph per ISCO group
			Figure S9. The comparison of the average Felten et al. (2021) and the PIAAC-based US AI exposures at the country level by ISCO-1d occupational groups and out-of-.sample prediction of AI exposures
		- Figure_1.png / .emf + Figure_1_legend.emf
			Figure 1. The comparison of the average Felten et al. (2021) and PIAAC/STEP-based AI exposures at the country level
		- Lewandowski_et_al_2025_AI_exposures.dta — final AI exposure dataset

6. 3_global_AI_distribution.do:
		- Table_1.xlsx — data for Table 1. 
			Table 1. Global distribution of the most/least AI-exposed workers, by country groups (in % of total employment in a given category of jobs)
*/

// Load paths
global data_source "...replication\data"
global output "...replication\outputs"
global codes "replication\codes"


do "${codes}\\1_microdata_regression_analysis.do" 
do "${codes}\\1_5_descriptive_statistics.do" 
do "${codes}\\1_6_Figure_S1_Tables10_15.do" 
do "${codes}\\1_7_Tables_S16_S21.do" 
do "${codes}\\2_out_of_sample_predictions.do"
do "${codes}\\3_global_AI_distribution.do" 

