

use "${data_source}\\main_dataset.dta", replace

// define variables for regressions

	global ICT_vars "ti_computer_use_sc ti_computer_use_sc2"
	global HC_vars "ageg10_1 ageg10_2 ageg10_4 ageg10_5 female educ3_1 educ3_3"
	global literacy_vars "@pv @1pv @2pv"
	global FIRM_vars "impute_firms_website impute_firms_foreign_tech impute_firms_certificate demean_gvcefsh demean_gvcebsh gvcefsh_demean_gdp_pc gvcebsh_demean_gdp_pc FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_demean_gdp_pc-FE_sector_18_demean_gdp_pc FE_sector_20_demean_gdp_pc"
	global DEV_vars "demean_gdp_pc"
// define sample of countries with available ISCO08 at 2-digit level
	global OCC_vars "isco2d_11-isco2d_51 isco2d_53-isco2d_96"
	reg aioe_piaac $ICT_vars $HC_vars lit4_pv10_1 lit4_pv10_3 lit4_pv10_4 $FIRM_vars $DEV_vars $OCC_vars cycle2 [pw=weight_std],  vce(cluster cluster_var)
	gen sample_isco2d = e(sample)

********************************************************************************
********************************************************************************
********************************************************************************
	// Table S6
********************************************************************************
********************************************************************************
********************************************************************************

		// Col 1 - without ISCO fe
		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
		mdd: reg aioe_piaac ///
			ti_computer_use_sc ti_computer_use_sc2 ///
			educ3_3 educ3_1  @pv @1pv @2pv female ///
			ageg10_1 ageg10_2 ageg10_4 ageg10_5 /// 
			demean_gvcefsh gvcefsh_demean_gdp_pc demean_gvcebsh  gvcebsh_demean_gdp_pc ///
			impute_firms_website impute_firms_foreign_tech impute_firms_certificate ///
			demean_gdp_pc cycle2 ///
			FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_demean_gdp_pc-FE_sector_18_demean_gdp_pc FE_sector_20_demean_gdp_pc [pw=weight_std] ,  vce(cluster cluster_var)
		outreg2 using "${output}\\TableS6.xls", excel append dec(3) ctitle("Col 1") label

		// Col 2 - ISCO08-1d level fe
		global OCC_vars "isco1d_1 isco1d_2 isco1d_3 isco1d_5 isco1d_7 isco1d_8 isco1d_9"
		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
			mdd: reg aioe_piaac ///
			ti_computer_use_sc ti_computer_use_sc2 ///
			educ3_3 educ3_1 @pv @1pv @2pv female ///
			ageg10_1 ageg10_2 ageg10_4 ageg10_5 /// 
			demean_gvcefsh gvcefsh_demean_gdp_pc demean_gvcebsh  gvcebsh_demean_gdp_pc ///
			impute_firms_website impute_firms_foreign_tech impute_firms_certificate ///
			demean_gdp_pc cycle2 ///
			FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_demean_gdp_pc-FE_sector_18_demean_gdp_pc FE_sector_20_demean_gdp_pc $OCC_vars [pw=weight_std] ,  vce(cluster cluster_var)
		outreg2 using "${output}\\TableS6.xls", excel append dec(3) ctitle("Col 2")

		// Col 3 - ISCO08-1d level fe, subsample of countries with ISCO08-2d available
		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
			mdd: reg aioe_piaac ///
			ti_computer_use_sc ti_computer_use_sc2 ///
			educ3_3 educ3_1 @pv @1pv @2pv female ///
			ageg10_1 ageg10_2 ageg10_4 ageg10_5 /// 
			demean_gvcefsh gvcefsh_demean_gdp_pc demean_gvcebsh  gvcebsh_demean_gdp_pc ///
			impute_firms_website impute_firms_foreign_tech impute_firms_certificate ///
			demean_gdp_pc cycle2 ///
			FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_demean_gdp_pc-FE_sector_18_demean_gdp_pc FE_sector_20_demean_gdp_pc $OCC_vars  [pw=weight_std] if sample_isco2d==1,  vce(cluster cluster_var)
		outreg2 using "${output}\\TableS6.xls", excel append dec(3) ctitle("Col 3")

		// Col 3 - ISCO08-2d level fe
		global OCC_vars "isco2d_11-isco2d_51 isco2d_53-isco2d_96"
		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
				mdd: reg aioe_piaac ///
			ti_computer_use_sc ti_computer_use_sc2 ///
			educ3_3 educ3_1 @pv @1pv @2pv female ///
			ageg10_1 ageg10_2 ageg10_4 ageg10_5 /// 
			demean_gvcefsh gvcefsh_demean_gdp_pc demean_gvcebsh  gvcebsh_demean_gdp_pc ///
			impute_firms_website impute_firms_foreign_tech impute_firms_certificate ///
			demean_gdp_pc cycle2 ///
			FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_demean_gdp_pc-FE_sector_18_demean_gdp_pc FE_sector_20_demean_gdp_pc $OCC_vars [pw=weight_std] if sample_isco2d==1,  vce(cluster cluster_var)
		outreg2 using "${output}\\TableS6.xls", excel append dec(3) ctitle("Col 4") label

********************************************************************************
********************************************************************************
********************************************************************************
// Figure 6 data
********************************************************************************
********************************************************************************
********************************************************************************

	
		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
		mdd: reg aioe_piaac $ICT_vars $HC_vars $literacy_vars $FIRM_vars $DEV_vars $OCC_vars cycle2 [pw=weight_std] if isco2d>=11 & isco2d<=36 & sample_isco2d==1,  vce(cluster cluster_var)
		outreg2 using "${output}\\Figure_S6_data.xls", excel append dec(3) ctitle("Isco1-3") label

		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
		mdd: reg aioe_piaac $ICT_vars $HC_vars $literacy_vars $FIRM_vars $DEV_vars $OCC_vars cycle2 [pw=weight_std] if isco2d>=41 & isco2d<=59 & sample_isco2d==1,  vce(cluster cluster_var)
		outreg2 using "${output}\\Figure_S6_data.xls", excel append dec(3) ctitle("Isco4-5") label

		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
		mdd: reg aioe_piaac $ICT_vars $HC_vars $literacy_vars $FIRM_vars $DEV_vars $OCC_vars cycle2 [pw=weight_std] if isco2d>=71 & isco2d<=98 & sample_isco2d==1,  vce(cluster cluster_var)
		outreg2 using "${output}\\Figure_S6_data.xls", excel append dec(3) ctitle("Isco7-9") label
// Distribution of computer use by ISCO groups
		su ti_computer_use_sc [w=weight_std] if isco2d>=11 & isco2d<=36, d

		su ti_computer_use_sc [w=weight_std] if isco2d>=41 & isco2d<=59, d

		su ti_computer_use_sc [w=weight_std] if isco2d>=71 & isco2d<=98, d

********************************************************************************
********************************************************************************
********************************************************************************
// Table S7
// Data for Figures S7 and S8
********************************************************************************
********************************************************************************
********************************************************************************

		// the order of variables is important and must be fixed
			global ICT_vars "ti_computer_use_sc ti_computer_use_sc2"
			global HC_vars "ageg10_1 ageg10_2 ageg10_4 ageg10_5 female educ3_1 educ3_3"
			global literacy_vars "@pv @1pv @2pv"
			global FIRM_vars "impute_firms_website impute_firms_foreign_tech impute_firms_certificate demean_gvcefsh demean_gvcebsh gvcefsh_demean_gdp_pc gvcebsh_demean_gdp_pc FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_demean_gdp_pc-FE_sector_18_demean_gdp_pc FE_sector_20_demean_gdp_pc"
			global DEV_vars "demean_gdp_pc"
			global OCC_vars "isco2d_11-isco2d_51 isco2d_53-isco2d_96"
		local dev_var_label "GDP per capita (log)"
		local ncol=2
		foreach dev_var in demean_gdp_pc ict_development dri_score i_ovrl_t i_lays_t uni_enr_t urbanisation_t  {
			di "`dev_var'"

		if "`dev_var'" == "ict_development" {
			local dev_var_label "ICT development index"
		}		
		if "`dev_var'" == "dri_score" {
			local dev_var_label "Digital Readiness Index"
		}		
		if "`dev_var'" == "i_ovrl_t" {
			local dev_var_label "Human Capital Index"
		}		
		if "`dev_var'" == "i_lays_t" {
			local dev_var_label "Learning adjusted years of schooling"
		}		
		if "`dev_var'" == "uni_enr_t" {
			local dev_var_label "Tertiary education enrolment rate"
		}		
		if "`dev_var'" == "urbanisation_t" {
			local dev_var_label "Urbanisation rate"
		}
		local ++ncol
		local col: word `ncol' of `c(ALPHA)'


		preserve

		if "`dev_var'"!="demean_gdp_pc"{

		su `dev_var' [iw = weight_std] //if country_code == "US" & cycle2==0
		gen `dev_var'_dm= `dev_var'-r(mean)

			gen gvcefsh_`dev_var' = demean_gvcefsh * `dev_var'_dm
			gen gvcebsh_`dev_var' = demean_gvcebsh * `dev_var'_dm
			*gen stin_`dev_var' = stingdp * `dev_var'_dm
		forval i=1/20{
			gen FE_sector_`i'_`dev_var' = FE_sector_`i' * `dev_var'_dm

			}
		}

		global FIRM_vars "impute_firms_website impute_firms_foreign_tech impute_firms_certificate demean_gvcefsh demean_gvcebsh gvcefsh_`dev_var' gvcebsh_`dev_var'  "		
		global DEV_vars "FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_`dev_var'-FE_sector_18_`dev_var'  FE_sector_20_`dev_var' `dev_var' "


		if "`dev_var'"=="demean_gdp_pc"{
		global FIRM_vars "impute_firms_website impute_firms_foreign_tech impute_firms_certificate demean_gvcefsh demean_gvcebsh gvcefsh_demean_gdp_pc gvcebsh_demean_gdp_pc"
		global DEV_vars "FE_sector_1-FE_sector_18 FE_sector_20 FE_sector_1_demean_gdp_pc-FE_sector_18_demean_gdp_pc FE_sector_20_demean_gdp_pc `dev_var' "
				
		}



		reg aioe_piaac $ICT_vars $HC_vars lit4_pv10_1 lit4_pv10_3 lit4_pv10_4 $FIRM_vars $DEV_vars $OCC_vars cycle2 [pw=weight_std],  vce(cluster cluster_var)
		gen sample = e(sample)

		noisily	pv, pv(lit4_pv*_1 ) pv1(lit4_pv*_3) pv2(lit4_pv*_4) ///
		mdd: reg aioe_piaac $ICT_vars $HC_vars $literacy_vars $FIRM_vars $DEV_vars $OCC_vars cycle2 [pw=weight_std],  vce(cluster cluster_var)


		predict y_hat
		matrix list r(table)


			
			matrix Tab = r(table)
			matrix e = J(1,rowsof(Tab),0)
			matrix e[1,1] = 1
			matrix B =   e * Tab
			matrix B = B'  // trasponowanie
		 
		// "missing" coefficients for base categories are set to 0, to not chagne prediction
				forvalues i = 1/`=rowsof(B)' {
					forvalues j = 1/`=colsof(B)' {
						if missing(B[`i', `j']) {
							matrix B[`i', `j'] = 0
						}
					}
				}


		local rows_B : rownames B
		local rows_no: word count `rows_B'
		di `rows_no'
		local ICT ""
		local hc_socio ""
		local literacy "" 
		local firm_wbes "" 
		local firm_macro "" 
		local firm_sector_fe "" 
		local gdp_sector_fe ""  
		local DEV ""
		local OCC ""
		local cycle2 ""
		local cons ""
		local seed_predict ""

		forval k=1/`rows_no'{

		di `k'

		if `k' <=2{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local ICT "`ICT' `predict_line' +"
			
		}

		if `k' >=3 & `k' <=9{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local hc_socio "`hc_socio' `predict_line' +"
			
		}

		if `k' >=10 & `k' <=12{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local literacy "`literacy' `predict_line' +"
			
		}

		if `k' >=13 & `k' <=15{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local firm_wbes "`firm_wbes' `predict_line' +"
			
		}

		if `k' >=16 & `k' <=19{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local firm_macro "`firm_macro' `predict_line' +"
			
		}

		if `k' >=20 & `k' <=38{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local firm_sector_fe "`firm_sector_fe' `predict_line' +"
			
		}

		if `k' >=39 & `k' <=57{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local gdp_sector_fe "`gdp_sector_fe' `predict_line' +"	
		}

		if `k' ==58{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local DEV "`DEV' `predict_line' +"	
		}

		if `k' >=59 & `k' <=94 {
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local OCC "`OCC' `predict_line' +"	
		}


		if `k' ==95{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local cycle2 "`cycle2' `predict_line' +"	
		}

		if `k' ==96{
			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local cons "`cons' `predict_line' +"	
		}

			local varname: word `k' of  `rows_B'
			local coeff= el(B,`k',1)
			local predict_line "`varname' * `coeff'"
			local seed_predict "`seed_predict' `predict_line' +"

			
			}

		global bv "`seed_predict' 0"
		global ICT "`ICT' 0"
		global hc_socio "`hc_socio' 0"
		global literacy "`literacy' 0" 
		global firm_wbes "`firm_wbes' 0"
		global firm_macro "`firm_macro' 0" 
		global firm_sector_fe "`firm_sector_fe' 0" 
		global gdp_sector_fe "`gdp_sector_fe' 0"  
		global DEV "`DEV' 0"
		global OCC "`OCC' 0"
		global cycle2 "`cycle2' 0"
		global cons "`cons' 0" 


		// by country
		*keep if sample == 1 
		keep if sample_isco2d==1

		collapse (mean) AI_country aioe_piaac $ICT_vars $HC_vars lit4_pv10_1 lit4_pv10_3 lit4_pv10_4 $FIRM_vars $DEV_vars $OCC_vars cycle2 [w=weight_std] , by(country_code time)		

		gen ICT= $ICT
		gen hc_socio = $hc_socio
		gen literacy = $literacy
		gen firm_wbes = $firm_wbes
		gen firm_macro = $firm_macro
		gen firm_sector_fe = $firm_sector_fe
		gen gdp_sector_fe = $gdp_sector_fe 
		gen cycle2_contribution = $cycle2
		gen cons = $cons 
		gen HC = hc_socio + literacy
		gen FIRM = firm_macro + firm_sector_fe + firm_wbes
		gen DEV = gdp_sector_fe + $DEV
		gen OCC = $OCC

		gen y= $bv
		gen check = ICT + HC + FIRM + DEV + OCC + cycle2_contribution + cons
		su y
		local avg_y r(mean)
		su check
		local avg_check r(mean)

		if `avg_y' == `avg_check'{
			di in red "OK"
		}

		if `avg_y' != `avg_check'{
			di in red "ATTENTION ERROR"
		}

		// real exposure
		corr aioe_piaac ICT HC FIRM DEV OCC hc_socio literacy firm_macro firm_sector_fe gdp_sector_fe cycle2_contribution firm_wbes cons, cov
		local y = r(Var_1)
		local ICT = r(C)[1,2] / `y' *100
		local HC = r(C)[1,3] / `y' *100
		local FIRM = r(C)[1,4] / `y' *100
		local DEV = r(C)[1,5] / `y' *100
		local OCC = r(C)[1,6] / `y' *100
		local hc_socio = r(C)[1,7] / `y' *100
		local literacy = r(C)[1,8] / `y' *100
		local firm_macro = r(C)[1,9] / `y' *100
		local Firm_sector_fe = r(C)[1,10] / `y' *100
		local gdp_sector_fe = r(C)[1,11] / `y' *100
		local cycle2_contribution = r(C)[1,12] / `y' *100
		local firm_wbes = r(C)[1,13] / `y' *100
		local contribution = `ICT' +  `HC' + `FIRM' + `OCC' + `DEV' + `cycle2_contribution'


		
		order  country_code  ICT HC FIRM DEV OCC cycle2_contribution y AI_country aioe_piaac hc_socio literacy firm_wbes firm_macro firm_sector_fe `dev_var' gdp_sector_fe 
		
		putexcel set "${output}\\Table_S7_and_Figure_2", sheet(Table S7) modify
		putexcel `col'1 = "`dev_var_label'"
		putexcel B2 = "ICT intensity"
		putexcel B3 = "Human capital"
		putexcel B4	= "Firm characteristics"
		putexcel B5 = "Occupational structure"
		putexcel B6 = "Development indicators"
		putexcel B7 = "Time trend"
		putexcel B8 = "Explained variance"
		putexcel B9 = "Literacy (part of Human Capital)"
		*putexcel `col'10="`dev_var'"

		putexcel `col'2=`ICT'
		putexcel `col'3=`HC'
		putexcel `col'4=`FIRM'
		putexcel `col'5=`OCC'
		putexcel `col'6=`DEV'
		putexcel `col'7=`cycle2_contribution'
		putexcel `col'8= `contribution'
		putexcel `col'9=`literacy'
		if "`dev_var'" == "demean_gdp_pc" {
					keep if inlist(country_code,"AT", "BE", "CL", "CZ", "DE", "ES", "FR", "HU", "IL") | inlist(country_code, "IT", "JP", "KR", "PL", "SG", "SK", "US")
			keep country_code	ICT	HC	FIRM	DEV	OCC	cycle2_contribution	y	AI_country	cons	cycle2
			order country_code	ICT	HC	FIRM	DEV	OCC	cycle2_contribution	y	AI_country	cons	cycle2
			reshape wide ICT	HC	FIRM	DEV	OCC	cycle2_contribution	y	AI_country	cons, i(country_code) j(cycle2)

			local vars ICT	HC	FIRM	DEV	OCC	cycle2_contribution	y	AI_country	
			foreach var of local vars{
				gen `var'_dif = `var'1-`var'0
			}

			keep country_code ICT_dif HC_dif FIRM_dif DEV_dif OCC_dif cycle2_contribution_dif y_dif AI_country_dif AI_country0

			rename *_dif *
			rename AI_country0 AI_country_initial
			export excel country_code ICT HC FIRM DEV OCC cycle2_contribution y AI_country AI_country_initial using "${output}\Figure_S7_8_data.xls", sheet("Figure_S7_8_data", modify) firstrow(variables) keepcellfmt  
		}
		
		
		restore

		}