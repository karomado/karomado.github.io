use "${data_source}\\raw_step_US.dta", clear


// Define questions/ task items used for approximation of ONET abilities for STEP survey
global	armhandsteadiness	 ti_physical ti_email ti_computer_use ti_presenting ti_presenting_rev ti_changing_order_rev ti_read_news ti_read_professional ti_spread ti_use_programming ti_supervising ti_complex_problems ti_fill_forms
global	auditoryattention	 ti_physical ti_email ti_computer_use ti_presenting ti_presenting_rev ti_changing_order_rev ti_read_news ti_read_professional ti_spread ti_use_programming ti_supervising ti_complex_problems ti_fill_forms
global	categoryflexibility	 ti_email ti_read_professional ti_computer_use ti_presenting ti_presenting_rev ti_physical ti_read_news ti_complex_problems ti_spread ti_fill_forms ti_use_programming ti_supervising ti_changing_order_rev
global	deductivereasoning	 ti_email ti_read_professional ti_presenting ti_presenting_rev ti_computer_use ti_read_news ti_physical ti_complex_problems ti_spread ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global	flexibilityofclosure	 ti_read_professional ti_complex_problems ti_email ti_read_news ti_presenting ti_presenting_rev ti_computer_use ti_spread ti_fill_forms ti_use_programming ti_supervising ti_physical ti_changing_order_rev
global	fluencyofideas	 ti_email ti_presenting ti_presenting_rev ti_read_professional ti_computer_use ti_physical ti_read_news ti_complex_problems ti_spread ti_supervising ti_changing_order_rev ti_fill_forms ti_use_programming
global	inductivereasoning	 ti_read_professional ti_presenting ti_presenting_rev ti_email ti_computer_use ti_read_news ti_physical ti_complex_problems ti_spread ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global	informationordering	 ti_email ti_read_professional ti_computer_use ti_presenting ti_presenting_rev ti_read_news ti_complex_problems ti_physical ti_spread ti_use_programming ti_fill_forms ti_supervising ti_changing_order_rev
global	mathematicalreasoning	 ti_email ti_computer_use ti_physical ti_presenting ti_presenting_rev ti_read_professional ti_read_news ti_complex_problems ti_spread ti_supervising ti_fill_forms ti_use_programming ti_changing_order_rev
global	memorization	 ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_email ti_read_news ti_physical ti_complex_problems ti_spread ti_fill_forms ti_supervising ti_use_programming ti_changing_order_rev
global	numberfacility	 ti_email ti_computer_use ti_physical ti_presenting ti_presenting_rev ti_read_professional ti_read_news ti_complex_problems ti_supervising ti_fill_forms ti_spread ti_use_programming ti_changing_order_rev
global	oralcomprehension	 ti_computer_use ti_read_professional ti_email ti_presenting ti_presenting_rev ti_read_news ti_physical ti_fill_forms ti_complex_problems ti_spread ti_supervising ti_changing_order_rev ti_use_programming
global	oralexpression	 ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_email ti_read_news ti_physical ti_fill_forms ti_spread ti_complex_problems ti_supervising ti_changing_order_rev ti_use_programming
global	originality	 ti_presenting ti_presenting_rev ti_read_professional ti_email ti_computer_use ti_read_news ti_physical ti_spread ti_complex_problems ti_supervising ti_changing_order_rev ti_use_programming ti_fill_forms
global	perceptualspeed	 ti_complex_problems ti_fill_forms ti_read_professional ti_use_programming ti_email ti_read_news ti_supervising ti_spread ti_computer_use ti_presenting ti_presenting_rev ti_changing_order_rev ti_physical
global	problemsensitivity	 ti_read_professional ti_presenting ti_presenting_rev ti_read_news ti_email ti_computer_use ti_complex_problems ti_fill_forms ti_spread ti_supervising ti_physical ti_changing_order_rev ti_use_programming
global	selectiveattention	 ti_complex_problems ti_read_professional ti_fill_forms ti_read_news ti_computer_use ti_presenting ti_presenting_rev ti_email ti_supervising ti_use_programming ti_spread ti_physical ti_changing_order_rev
global	speechclarity	 ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_email ti_read_news ti_physical ti_fill_forms ti_spread ti_complex_problems ti_supervising ti_changing_order_rev ti_use_programming
global	speechrecognition	 ti_computer_use ti_email ti_physical ti_read_professional ti_read_news ti_presenting ti_presenting_rev ti_fill_forms ti_supervising ti_complex_problems ti_spread ti_changing_order_rev ti_use_programming
global	speedofclosure	 ti_read_professional ti_email ti_computer_use ti_read_news ti_presenting ti_presenting_rev ti_complex_problems ti_physical ti_fill_forms ti_spread ti_supervising ti_use_programming ti_changing_order_rev
global	stamina	 ti_physical ti_email ti_computer_use ti_read_professional ti_read_news ti_presenting ti_presenting_rev ti_fill_forms ti_complex_problems ti_spread ti_use_programming ti_changing_order_rev ti_supervising
global	timesharing	 ti_supervising ti_fill_forms ti_read_professional ti_read_news ti_presenting ti_presenting_rev ti_complex_problems ti_computer_use ti_physical ti_spread ti_use_programming ti_email ti_changing_order_rev
global	visualization	 ti_complex_problems ti_physical ti_use_programming ti_spread ti_read_professional ti_computer_use ti_supervising ti_presenting ti_presenting_rev ti_read_news ti_changing_order_rev ti_fill_forms ti_email
global	writtencomprehension	 ti_email ti_computer_use ti_read_professional ti_physical ti_presenting ti_presenting_rev ti_read_news ti_complex_problems ti_spread ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global	writtenexpression	 ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global armhandsteadiness ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global dynamicstrength ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global extentflexibility ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global grossbodycoordination ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global hearingsensitivity ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global nearvision ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global responseorientation ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global spatialorientation ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global speedoflimbmovement ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global staticstrength ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming
global visualcolordis ti_email ti_computer_use ti_presenting ti_presenting_rev ti_read_professional ti_physical ti_read_news ti_spread ti_complex_problems ti_fill_forms ti_supervising ti_changing_order_rev ti_use_programming


gen y_hat=.

levelsof onet_element if ability_sample==1, local(element)
foreach e of local element{
	if "`e'" == "armhandsteadiness" {
		local title "Arm-hand steadiness"
	}

	if "`e'" == "auditoryattention" {
		local title "Auditory attention"
	}

	if "`e'" == "categoryflexibility" {
		local title "Category flexibility"
	}

	if "`e'" == "deductivereasoning" {
		local title "Deductive reasoning"
	}

	if "`e'" == "dynamicstrength" {
		local title "Dynamic strength"
	}

	if "`e'" == "extentflexibility" {
		local title "Extent flexibility"
	}

	if "`e'" == "flexibilityofclosure" {
		local title "Flexibility of closure"
	}

	if "`e'" == "fluencyofideas" {
		local title "Fluency of ideas"
	}

	if "`e'" == "grossbodycoordination" {
		local title "Gross body coordination"
	}

	if "`e'" == "hearingsensitivity" {
		local title "Hearing sensitivity"
	}

	if "`e'" == "inductivereasoning" {
		local title "Inductive reasoning"
	}

	if "`e'" == "informationordering" {
		local title "Information ordering"
	}

	if "`e'" == "mathematicalreasoning" {
		local title "Mathematical reasoning"
	}

	if "`e'" == "memorization" {
		local title "Memorization"
	}

	if "`e'" == "nearvision" {
		local title "Near vision"
	}

	if "`e'" == "numberfacility" {
		local title "Number facility"
	}

	if "`e'" == "oralcomprehension" {
		local title "Oral comprehension"
	}

	if "`e'" == "oralexpression" {
		local title "Oral expression"
	}

	if "`e'" == "originality" {
		local title "Originality"
	}

	if "`e'" == "perceptualspeed" {
		local title "Perceptual speed"
	}

	if "`e'" == "problemsensitivity" {
		local title "Problem sensitivity"
	}

	if "`e'" == "responseorientation" {
		local title "Response orientation"
	}

	if "`e'" == "selectiveattention" {
		local title "Selective attention"
	}

	if "`e'" == "spatialorientation" {
		local title "Spatial orientation"
	}

	if "`e'" == "speechclarity" {
		local title "Speech clarity"
	}

	if "`e'" == "speechrecognition" {
		local title "Speech recognition"
	}

	if "`e'" == "speedofclosure" {
		local title "Speed of closure"
	}

	if "`e'" == "speedoflimbmovement" {
		local title "Speed of limb movement"
	}

	if "`e'" == "stamina" {
		local title "Stamina"
	}

	if "`e'" == "staticstrength" {
		local title "Static strength"
	}

	if "`e'" == "timesharing" {
		local title "Time sharing"
	}

	if "`e'" == "visualcolordis" {
		local title "Visual color discrimination"
	}

	if "`e'" == "visualization" {
		local title "Visualization"
	}

	if "`e'" == "writtencomprehension" {
		local title "Written comprehension"
	}

	if "`e'" == "writtenexpression" {
		local title "Written expression"
		
	}	
		label var scalar "`title'"
		di "`e'"
		di "`title'"	
	
	
	qui reg scalar ib1.(${`e'}) if onet_element == "`e'", nocons
	 qui outreg2 using "${output}\Tables_S16_S21.xls", ctitle("`title'") dec(3) label

}