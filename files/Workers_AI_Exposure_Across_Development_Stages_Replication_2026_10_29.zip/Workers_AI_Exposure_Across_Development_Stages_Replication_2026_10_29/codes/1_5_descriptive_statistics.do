
use "${data_source}\\main_dataset.dta", replace



preserve 
	collapse  aioe_piaac  aioe_felten aioe_felten_us  [w=weight_std], by( ln_gdp_pc_t country_code  cycle2)
	// Exposure for China in 2022–2023 was calculated at CASS on local computers, as the newest CULS data are still under embargo for foreign researchers.
	expand 2 if country_code =="CN"
	bys country_code : gen n=_n
	replace ln_gdp_pc_t = 10.021067 if country_code=="CN" & n==2
	replace cycle2 = 1 if n==2 & country_code=="CN"
	replace aioe_piaac  = -.4325989 if country_code == "CN" & cycle2==1
	replace aioe_felten = -.335389 if country_code == "CN" & cycle2==1
	replace aioe_felten_us  = -.2774643 if country_code == "CN" & cycle2==1

********************************************************************************
********************************************************************************
********************************************************************************
//Figure S3
********************************************************************************
********************************************************************************
********************************************************************************
			local color_line "0 0 0"
			local color1 "0 0 0*.6"
			local color2 "0 0 0*.3"
	// Left panel
	// Felten et al. (2022)
		twoway scatter aioe_felten ln_gdp_pc_t if cycle2==0 & country_code!="US", mlabel(country_code) mlabpos(12)  mfcolor("`color1'") mlcolor(none) mlabc("`color1'") ///
		|| scatter aioe_felten ln_gdp_pc_t if cycle2==1, mlabel(country_code) mlabpos(12) mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==0 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("black") mlcolor(none) mlabc("black") msymbol(diamond) msiz(medlarge)  ///
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==1 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("black*.6") mlcolor(none) mlabc("black*.8") msymbol(diamond) msiz(medlarge)  /// 
		|| qfit aioe_felten  ln_gdp_pc_t  , lcolor("`color_line'") title("AIOE Felten et al. (2021)",size(med)) ylabel(-1 "-1.0" -0.8 "-0.8" -0.6 "-0.6" -0.4 "-0.4" -0.2 "-0.2" 0 "0" 0.2 "0.2" 0.4 "0.4",labsize(med)) xlabel(,labsize(med)) xtitle("GDP per capita (log)",size(med)) ytitle("The average AI exposure",size(med))  yline(0,lp(dash) lw(vthin) lc(black)) name(S3LP, replace) graphregion(margin(zero)) legend(order(1 "2011-2018" 2 "2022-2023" ) ) // size(large)

			local color_line "180 22 58"
			local color1 "180 22 58"
			local color2 "180 22 58*.4"
	// Right panel
	// Lewandowski et al. (2025)
		twoway scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==0 & country_code!="US", mlabel(country_code) mlabpos(12)  mfcolor("`color1'") mlcolor(none) mlabc("`color1'")  ///
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==1 & country_code!="US", mlabel(country_code) mlabpos(12)  mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==0 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) /// 
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==1 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("red*0.7") mlcolor(none) mlabc("red*.7") msymbol(diamond) msiz(medlarge) /// 		
		|| qfit aioe_piaac  ln_gdp_pc_t  , lcolor("`color_line'")  title("Country-specific AI exposures",size(med)) ylabel(-1 "-1.0" -0.8 "-0.8" -0.6 "-0.6" -0.4 "-0.4" -0.2 "-0.2" 0 "0" 0.2 "0.2" 0.4 "0.4",labsize(med)) xlabel(,labsize(med)) xtitle("GDP per capita (log)",size(med)) ytitle("The average AI exposure",size(med)) yline(0,lp(dash) lw(vthin) lc(black)) name(S3RP, replace)  graphregion(margin(zero)) legend(order(1 "Survey 2011-2018" 2 "Survey 2022-2023") ) //size(large)
		
		graph combine S3LP S3RP, ycommon graphregion(margin(zero))
		graph export "${output}\\Figure_S3.png", as(png) replace
		graph export "${output}\\Figure_S3.emf", as(emf) replace
		
********************************************************************************
********************************************************************************
********************************************************************************
//Figure S4
********************************************************************************
********************************************************************************
********************************************************************************		
			local color_line "0 0 0"
			local color1 "0 0 0*.6"
			local color2 "0 0 0*.3"
	
		// Felten
		twoway scatter aioe_felten ln_gdp_pc_t if cycle2==0 & country_code!="US", mlabel(country_code) mlabpos(12)  mfcolor("`color1'") mlcolor(none) mlabc("`color1'") ///
		|| scatter aioe_felten ln_gdp_pc_t if cycle2==1 & country_code!="US", mlabel(country_code) mlabpos(12) mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==0 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("black") mlcolor(none) mlabc("black") msymbol(diamond)msiz(medlarge)  /// 
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==1 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("black*.6") mlcolor(none) mlabc("black*.8") msymbol(diamond) msiz(medlarge)  /// 
		|| qfit aioe_felten  ln_gdp_pc_t  , lcolor("`color_line'") title("AIOE Felten et al. (2021)",size(med)) ylabel(-1 "-1.0" -0.8 "-0.8" -0.6 "-0.6" -0.4 "-0.4" -0.2 "-0.2" 0 "0" 0.2 "0.2" 0.4 "0.4",labsize(med)) xlabel(,labsize(med)) xtitle("GDP per capita (log)",size(med)) ytitle("The average AI exposure",size(med))  yline(0,lp(dash) lw(vthin) lc(black)) name(S4LP, replace) graphregion(margin(zero)) legend(order(1 "Survey 2011-2018" 2 "Survey 2022-2023"))

			local color_line "180 22 58"
			local color1 "180 22 58"
			local color2 "180 22 58*.4"
		
// Country-level exposures according to PIAAC-based exposures		
		// PIAAC 
		twoway scatter aioe_felten_us  ln_gdp_pc_t if cycle2 ==0 & country_code!="US", mlabel(country_code) mlabpos(12)  mfcolor("`color1'") mlcolor(none) mlabc("`color1'")  ///
		|| scatter aioe_felten_us  ln_gdp_pc_t if cycle2 ==1  & country_code!="US", mlabel(country_code) mlabpos(12)  mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==0 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) /// 
		|| scatter aioe_piaac  ln_gdp_pc_t if cycle2 ==1 & country_code=="US", mlabel(country_code) mlabpos(12)  mfcolor("red*.6") mlcolor(none) mlabc("red*.8") msymbol(diamond) msiz(medlarge)  /// 
		|| qfit aioe_felten_us  ln_gdp_pc_t  , lcolor("`color_line'")  title("US-survey based AI exposures",size(med)) ylabel(-1 "-1.0" -0.8 "-0.8" -0.6 "-0.6" -0.4 "-0.4" -0.2 "-0.2" 0 "0" 0.2 "0.2" 0.4 "0.4",labsize(med)) xlabel(,labsize(med)) xtitle("GDP per capita (log)",size(med)) ytitle("The average AI exposure",size(med)) yline(0,lp(dash) lw(vthin) lc(black)) name(S4RP, replace)  graphregion(margin(zero)) legend(order(1 "Survey 2011-2018" 2 "Survey 2022-2023"))
			
		
		graph combine S4LP S4RP, ycommon graphregion(margin(zero))
		graph export "${output}\Figure_S4.png", as(png) replace
		graph export "${output}\Figure_S4.emf", as(emf) replace		
restore


********************************************************************************
********************************************************************************
********************************************************************************
//Figure S5
********************************************************************************
********************************************************************************
********************************************************************************	

preserve

// For "Canada","China","Estonia","Finland","Philippines" there are available only ISCO08-1d occupational codes.
cap drop isco08_1d 
gen isco08_1d = isco08_2d
replace isco08_1d = .  if isco08_1d <10 & !inlist(country,"Canada","China","Estonia","Finland","Philippines")
replace isco08_1d = floor(isco08_1d/10) if  !inlist(country,"Canada","China","Estonia","Finland","Philippines")
ta isco08_1d 

egen tot_w = total(weight_std), by(country_code source isco08_1d)

collapse aioe_piaac   (max) tot_w  [w=weight_std], by(ln_gdp_pc_t country_code  cycle2 isco08_1d)
drop if mi(isco08_1d)

// Exposure for China in 2022–2023 was calculated at CASS on local computers, as the newest CULS data are still under embargo for foreign researchers.

expand 2 if country_code =="CN"
bys country_code isco08_1d: gen n=_n
replace ln_gdp_pc_t = 10.021067 if country_code=="CN" & n==2
replace cycle2 = 1 if country_code=="CN" & n==2

replace aioe_piaac  = -.2212012 if country_code == "CN" & isco08_1d == 1 & cycle2 == 1
replace aioe_piaac  = -.5883943 if country_code == "CN" & isco08_1d == 2 & cycle2 == 1
replace aioe_piaac  = -.5249228 if country_code == "CN" & isco08_1d == 3 & cycle2 == 1
replace aioe_piaac  = .4251474 if country_code == "CN" & isco08_1d == 4 & cycle2 == 1
replace aioe_piaac  = -.4564884 if country_code == "CN" & isco08_1d == 5 & cycle2 == 1
replace aioe_piaac  = -1.33528 if country_code == "CN" & isco08_1d == 7 & cycle2 == 1
replace aioe_piaac  = -1.222149 if country_code == "CN" & isco08_1d == 8 & cycle2 == 1
replace aioe_piaac  = -.8090683 if country_code == "CN" & isco08_1d == 9 & cycle2 == 1

// Countries with ISCO08-1d
keep if inlist(country_code,"US","CN","PH","EE","CA","FI") & cycle2==0

// standardise weights
ren tot_w w
egen tot_w = total(w), by(country_code cycle2) 
replace w = w/tot_w

gen exp_partial = aioe_piaac  * w
egen exp_country = total(exp_partial), by(country_code  cycle2)

//occupational exposures 
drop exp_partial 
gen exp_partial = aioe_piaac 

gen w_US = w if country_code=="US"
ereplace w_US = max(w_US), by(isco08_1d)
gen exp_partial_US = aioe_piaac  if country_code=="US"
ereplace exp_partial_US = max(exp_partial_US), by(isco08_1d)
gen exp_country_US = exp_country if country_code=="US"
ereplace exp_country_US = max(exp_country_US)

// define change in exposure

gen change = exp_country - exp_country_US 

// Between effect

gen BE = (w - w_US) * exp_partial_US

// Within effect

gen WE = w_US * (exp_partial - exp_partial_US)

// interaction

gen IE = (w - w_US) * (exp_partial - exp_partial_US)


ereplace BE = total(BE), by(country_code cycle2)
ereplace WE = total(WE), by(country_code cycle2)
ereplace IE = total(IE), by(country_code cycle2)

gen x = BE + WE + IE

gen AI_exposure = x
gen Task_related_difference = WE
gen Occupational_structure = BE
gen Measurement_change = IE
keep if isco08_1d==1
sort AI_exposure 
order country_code AI_exposure WE BE IE 
keep country_code AI_exposure WE BE IE 
drop if country_code == "US" 

expand 2 if country_code=="CN"
bys country_code: gen n=_n
replace country_code = "CN (2023)" if n==2
replace AI_exposure	= -.6410554 if country_code=="CN (2023)"
replace WE	= -.5390846 if country_code=="CN (2023)"
replace BE	= -.2631667 if country_code=="CN (2023)"
replace IE	= 0.1611959 if country_code=="CN (2023)"
drop n

tempfile shift_share_isco1d
save `shift_share_isco1d'
restore


//////////////////////
*2d
preserve
drop if mi(isco08_2d)
drop if isco08_2d<10
egen tot_w = total(weight_std), by(country_code source isco08_2d)

collapse aioe_piaac  (max) tot_w (count) n=aioe_piaac  [w=weight_std], by(ln_gdp_pc_t country_code  cycle2 isco08_2d )

// standardise weights
ren tot_w w
egen tot_w = total(w), by(country_code cycle2) 
replace w = w/tot_w

// country-level exposures
gen exp_partial = aioe_piaac  * w
egen exp_country = total(exp_partial), by(country_code cycle2)


//occupational exposures 
drop exp_partial 
gen exp_partial = aioe_piaac 

gen w_US = w if country_code=="US" & cycle2==0
ereplace w_US = max(w_US), by(isco08_2d)
gen exp_partial_US = aioe_piaac  if country_code=="US" & cycle2==0
ereplace exp_partial_US = max(exp_partial_US), by(isco08_2d)
gen exp_country_US = exp_country if country_code=="US" & cycle2==0
ereplace exp_country_US = max(exp_country_US)

// define change in exposure

gen change = exp_country - exp_country_US 

// Between effect

gen BE = (w - w_US) * exp_partial_US

// Within effect

gen WE = w_US * (exp_partial - exp_partial_US)

// interaction

gen IE = (w - w_US) * (exp_partial - exp_partial_US)


ereplace BE = total(BE), by(country_code cycle2)
ereplace WE = total(WE), by(country_code cycle2)
ereplace IE = total(IE), by(country_code cycle2)

gen x = BE + WE + IE

gen AI_exposure = x
gen Task_related_difference = WE
gen Occupational_structure = BE
gen Measurement_change = IE
sort AI_exposure 
order country_code AI_exposure WE BE IE 
keep country_code AI_exposure WE BE IE cycle2
duplicates drop

levelsof country_code if cycle2==1, local(countries)
foreach country of local countries{
	replace country_code = "`country' (2021-2022)" if country_code=="`country'" & cycle2==1
	
	if "`country'" == "CN"{
		replace country_code = "`country' (2023)" if country_code=="`country'" & cycle2==1
		
	}
}
drop cycle2


tempfile shift_share_isco2d
save `shift_share_isco2d'
restore

use `shift_share_isco1d', clear
append using `shift_share_isco2d'

sort AI_exposure

export excel country_code AI_exposure WE BE IE using "${output}\Figure_S5.xls", sheet("Figure_S5_data", modify) firstrow(variables) keepcellfmt 