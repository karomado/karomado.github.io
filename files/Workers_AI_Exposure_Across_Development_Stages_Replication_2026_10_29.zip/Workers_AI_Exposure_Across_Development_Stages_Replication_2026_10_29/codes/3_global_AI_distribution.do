use "${data_source}\\global_employment.dta", clear


preserve 
use "${output}\piaac_based_ai_exposures_full_sample_prediction.dta" , clear
keep if cycle2 == 1
reshape long ai_exp_1d_ ai_exp_2d_, i(country_code) j(isco)
gen ai_exposure = ai_exp_2d_
replace ai_exposure = ai_exp_1d_  if mi(ai_exposure)
save "${output}\ai_exposure_long.dta", replace
restore 

cap drop _merge
merge m:1 country_code_3d isco using "${output}\ai_exposure_long.dta", keepus(ai_exposure country_name source)
drop if _merge==2
gen isco2d = isco if isco>10
gen isco1d = isco if isco<10
 
gen empl_weight=floor(employment) if !mi(ai_exposure)

gen final_ai_p10=.
gen final_ai_p25=.
gen final_ai_p50=.
gen final_ai_p75=.
gen final_ai_p90=.

	_pctile ai_exposure if country_group>1 & country_group<6 [aw = empl_weight], percentile(10, 25, 50, 75, 90)
		
	replace final_ai_p10=r(r1) 
	replace final_ai_p25=r(r2) 
	replace final_ai_p50=r(r3) 
	replace final_ai_p75=r(r4) 
	replace final_ai_p90=r(r5) 
		
********************************************************************************
********************************************************************************
********************************************************************************
// Table 1
********************************************************************************
********************************************************************************
********************************************************************************	
	putexcel set "${output}\\Table_1", sheet(Table 1) modify

	keep if country_group<6
	
	gen bot_25 = 0
	replace bot_25 = 1 if ai_exposure <= final_ai_p25 & !mi(ai_exposure)
	gen top_25 = 0
	replace top_25 = 1 if ai_exposure >= final_ai_p75 & !mi(ai_exposure)
	
	egen total_emp = total(employment), by(country_code_3d)
	egen total_emp_glob = total(employment) if !mi(ai_exposure) //& inlist(country_group,2,3,4,5)
	
	egen sum_top = total(employment) if top_25==1, by(country_code_3d) 
	egen sum_bot = total(employment) if bot_25==1, by(country_code_3d) 
	
	gen share_top = sum_top / total_emp
	gen share_bot = sum_bot / total_emp

	gen share_top_global = sum_top / total_emp_glob
	gen share_bot_global = sum_bot / total_emp_glob
	
	ereplace share_top = max(share_top), by(country)
	ereplace share_bot = max(share_bot), by(country)

	ereplace share_top_global = max(share_top_global), by(country)
	ereplace share_bot_global = max(share_bot_global), by(country)
	
	
	replace share_top = 0 if mi(share_top) & !mi(ai_exposure) & !mi(employment)
	replace share_bot = 0 if mi(share_bot) & !mi(ai_exposure) & !mi(employment)
	replace share_top_global = 0 if mi(share_top_global) & !mi(ai_exposure) & !mi(employment)
	replace share_bot_global = 0 if mi(share_bot_global) & !mi(ai_exposure) & !mi(employment)

	keep if !mi(ai_exposure)

	
	
	putexcel B1="Low or lower-middle income"
	putexcel C1="Upper-middle income"
	putexcel D1="High-income"
	putexcel A2="Most exposed (top 25%)"
	putexcel A3="Least exposed (bottom 25%)"
	putexcel A4="Total employment"

	// employment share by country groups
	cap drop total_emp_country_group 
	egen total_emp_country_group = total(employment) if !mi(ai_exposure) , by(country_group)

	su total_emp_glob 
	local global_emp = r(mean)
	su total_emp_country_group if inlist(country_group,2)
	local emp_country1 = r(mean)
	di "Low or lower-middle income:" `emp_country1' / `global_emp'

	su total_emp_country_group if inlist(country_group,3)
	local emp_country2 = r(mean)
	di "Upper-middle income:" `emp_country2' / `global_emp'

// For presentation purposes high-income and top-high-income countries are pulled into 1 group
	su total_emp_country_group if inlist(country_group,4)
	local emp_country31 = r(mean)
	su total_emp_country_group if inlist(country_group,5)
	local emp_country32 = r(mean)
	
	local emp_country3 = `emp_country31' + `emp_country32'
	di "High-income:" `emp_country3' / `global_emp'
	
	local country_group1_emp = `emp_country1' / `global_emp' 
	local country_group2_emp = `emp_country2' / `global_emp' 
	local country_group3_emp = `emp_country3' / `global_emp' 
	local total = `country_group1_emp' + `country_group2_emp' + `country_group3_emp'
	// Ensure shares add up to 100 and round
	local country_group1_emp = round(`country_group1_emp' / `total' * 100,0.1)
	local country_group2_emp = round(`country_group2_emp' / `total' * 100,0.1)
	local country_group3_emp = round(`country_group3_emp' / `total' * 100,0.1)
	
	di `country_group1_emp'
	di `country_group2_emp'
	di `country_group3_emp'
	di `country_group1_emp' + `country_group2_emp' + `country_group3_emp'
	
	putexcel B4=`country_group1_emp' C4=`country_group2_emp' D4=`country_group3_emp' 
	
// TOP
	egen top_tot_all = total(employment) if !mi(ai_exposure) & !mi(employment), by(top_25)
	egen top_25_cg = total(employment) if !mi(ai_exposure) & !mi(employment), by(top_25 country_group)

	*Low or lower-middle income	
	su top_25_cg if top_25==1 & country_group==2
	local top_emp1 = r(mean)
	*Middle-income
	su top_25_cg if top_25==1 & country_group==3
	local top_emp2 = r(mean)
	*High-income
	su top_25_cg if top_25==1 & inlist(country_group,4)
	local top_emp31 = r(mean)
	su top_25_cg if top_25==1 & inlist(country_group,5)
	local top_emp32 = r(mean)
	local top_emp3 = `top_emp31' + `top_emp32' 
	
	local top_emp_global = `top_emp1' + `top_emp2' + `top_emp3'
	
	local country_group1_top = round(`top_emp1' / `top_emp_global' * 100,0.1)
	local country_group2_top = round(`top_emp2' / `top_emp_global' * 100,0.1)
	local country_group3_top = round(`top_emp3' / `top_emp_global' * 100,0.1)
	di `country_group1_top'
	di `country_group2_top'
	di `country_group3_top'
	putexcel B2=`country_group1_top' C2=`country_group2_top' D2=`country_group3_top' 
	
	
//BOT
	egen bot_tot_all = total(employment) if !mi(ai_exposure) & !mi(employment), by(bot_25)
	egen bot_25_cg = total(employment) if !mi(ai_exposure) & !mi(employment), by(bot_25 country_group)
	
	su bot_tot_all if bot_25==1
	*Low or lower-middle income	
	su bot_25_cg if bot_25==1 & country_group==2
	local bot_emp1 = r(mean)
	*Middle-income
	su bot_25_cg if bot_25==1 & country_group==3
	local bot_emp2 = r(mean)
	*High-income
	su bot_25_cg if bot_25==1 & inlist(country_group,4)
	local bot_emp31 = r(mean)
	su bot_25_cg if bot_25==1 & inlist(country_group,5)
	local bot_emp32 = r(mean)
	local bot_emp3 = `bot_emp31' + `bot_emp32' 
	
	local bot_emp_global = `bot_emp1' + `bot_emp2' + `bot_emp3'
	
	local country_group1_bot = round(`bot_emp1' / `bot_emp_global' * 100,0.1)
	local country_group2_bot = round(`bot_emp2' / `bot_emp_global' * 100,0.1)
	local country_group3_bot = round(`bot_emp3' / `bot_emp_global' * 100,0.1)
	di `country_group1_bot' 
	di `country_group2_bot' 
	di `country_group3_bot'
	putexcel B3=`country_group1_bot' C3=`country_group2_bot' D3=`country_group3_bot' 	
	

// erase redundant temporary files
erase "${output}\\piaac_based_ai_exposures_full_sample_prediction.dta"
erase "${output}\ai_exposure_long.dta"
	