use "${data_source}\\raw_piaac_US.dta", clear




// Fit PIAAC-based AI exposere for the US to exposure by Felten et al. (2021) at ISCO08-2d level. 

// Exclude abilities not approximated with PIAAC work-related questions
	replace ability_sample=1
	replace onet_element = "visualcolordis" if onet_element=="visualcolordiscrimination"
	replace ability_sample = 0 if inlist(onet_element,"controlprecision", "depthperception", "dynamicflexibility", "explosivestrength", "farvision") ///
		| inlist(onet_element,"fingerdexterity", "glaresensitivity", "grossbodyequilibrium", "manualdexterity", "multilimbcoordination", "nightvision") ///
		| inlist(onet_element,"peripheralvision", "ratecontrol", "reactiontime", "soundlocalization", "trunkstrength", "wristfingerspeed")

// Define set of abilities that approximate each ability
	global armhandsteadiness g_q05a f_q02c g_q01g
	global auditoryattention f_q06b g_q01c f_q02c
	global categoryflexibility g_q05a f_q05b f_q03a f_q03c f_q02c
	global controlprecision g_q05a f_q02c g_q01g g_q03b
	global deductivereasoning g_q05a f_q03a f_q05b f_q03c f_q02c
	global depthperception g_q05a f_q02c g_q03b
	global dynamicflexibility g_q05a g_q02d f_q02c g_q01f f_q05b f_q03c g_q01g d_q08a
	global dynamicstrength g_q05a f_q02c f_q03c f_q03a g_q02d g_q01g f_q05b d_q11a
	global explosivestrength g_q05a f_q03c g_q01g f_q03a d_q11a g_q03b g_q05g f_q02c
	global extentflexibility g_q05a f_q02c f_q03c g_q01g g_q02d f_q03a f_q05b d_q08a
	global farvision g_q03b f_q06b d_q08a g_q01d g_q01f g_q03h f_q03a f_q05b
	global fingerdexterity f_q06b f_q02c g_q01c g_q03b g_q01g g_q01d f_q03a d_q11a
	global flexibilityofclosure g_q05a f_q05b f_q03c f_q03a g_q01f g_q02d g_q03h
	global fluencyofideas g_q05a f_q02c f_q03a
	global glaresensitivity g_q05a f_q02c f_q03c d_q11a f_q03a g_q03b g_q02d f_q05b
	global grossbodycoordination g_q05a f_q02c f_q03c f_q03a f_q05b g_q02d g_q01g d_q11a
	global grossbodyequilibrium g_q05a f_q03c f_q02c f_q03a g_q01g g_q02d d_q11a f_q05b
	global hearingsensitivity f_q06b g_q03b f_q02c g_q01g g_q01c d_q11a g_q01d f_q03a
	global inductivereasoning g_q05a f_q05b f_q03a f_q02c f_q03c g_q02d
	global informationordering g_q05a f_q05b f_q03a
	global manualdexterity g_q05a f_q02c g_q01g
	global mathematicalreasoning g_q05a f_q05b f_q03c f_q03a d_q08a f_q02c g_q03h g_q01g
	global memorization g_q05a f_q02c f_q03a
	global multilimbcoordination g_q05a f_q02c f_q03c f_q03a g_q01g d_q11a f_q05b g_q03b
	global nearvision g_q05a f_q05b f_q03c g_q02d f_q03a
	global nightvision g_q05a f_q02c f_q03c d_q11a f_q03a g_q03b f_q05b g_q05g
	global numberfacility g_q05a f_q05b d_q08a f_q03c f_q03a g_q01g g_q02d g_q03h
	global oralcomprehension g_q05a f_q02c f_q03a
	global oralexpression g_q05a f_q02c f_q03a
	global originality g_q05a f_q02c f_q03a
	global perceptualspeed f_q05b g_q02d g_q03b g_q01d g_q01f g_q05a g_q03h g_q05g
	global peripheralvision g_q05a f_q03c f_q02c d_q11a f_q03a f_q05b g_q05g g_q03b
	global problemsensitivity g_q05a f_q05b f_q03a
	global ratecontrol g_q05a f_q02c f_q03c f_q03a d_q11a g_q01g g_q03b f_q05b
	global reactiontime g_q05a f_q02c f_q03c f_q03a d_q11a g_q03b g_q01g d_q08a
	global responseorientation g_q05a f_q02c f_q03c g_q03b f_q03a d_q11a g_q01g f_q05b
	global selectiveattention g_q05a f_q05b g_q02d g_q01f
	global soundlocalization g_q05a f_q02c f_q03c d_q11a f_q03a g_q03b g_q01g
	global spatialorientation g_q05a f_q02c f_q03c f_q03a d_q11a f_q05b g_q02d g_q05g
	global speechclarity g_q05a f_q02c f_q03a
	global speechrecognition g_q05a f_q02c g_q02d
	global speedofclosure g_q05a f_q05b f_q03a
	global speedoflimbmovement g_q05a f_q02c f_q03c f_q03a g_q02d g_q01g f_q05b d_q11a
	global stamina g_q05a f_q02c f_q03c f_q03a f_q05b g_q02d g_q01g d_q11a
	global staticstrength g_q05a f_q02c f_q03c f_q03a g_q01g f_q05b g_q02d d_q11a
	global timesharing d_q08a g_q02d g_q01d g_q01f g_q01c f_q05b f_q01b g_q05a
	global trunkstrength g_q05a f_q03c f_q03a f_q02c g_q01g f_q05b g_q02d d_q11a
	global visualcolordis f_q06b g_q03b g_q01g f_q02c g_q01c f_q01b g_q01d d_q11a
	global visualization g_q03h g_q03b f_q05b g_q05g f_q06b g_q01f g_q01g g_q01d
	global wristfingerspeed g_q05a f_q02c f_q03a f_q03c g_q01g d_q11a d_q08a g_q03b
	global writtencomprehension g_q05a f_q02c f_q03a
	global writtenexpression g_q05a f_q02c f_q03a f_q03c f_q05b g_q02d d_q08a g_q01f

		

********************************************************************************
********************************************************************************
********************************************************************************
//Tables10_15
********************************************************************************
********************************************************************************
********************************************************************************
// Run regression procedure

	gen y_hat=.
	levelsof onet_element if ability_sample==1, local(element)
	foreach e of local element{
	if "`e'" == "armhandsteadiness" {
		local title "Arm-hand steadiness"
	}

	if "`e'" == "auditoryattention" {
		local title "Auditory attention"
	}

	if "`e'" == "categoryflexibility" {
		local title "Category flexibility"
	}

	if "`e'" == "deductivereasoning" {
		local title "Deductive reasoning"
	}

	if "`e'" == "dynamicstrength" {
		local title "Dynamic strength"
	}

	if "`e'" == "extentflexibility" {
		local title "Extent flexibility"
	}

	if "`e'" == "flexibilityofclosure" {
		local title "Flexibility of closure"
	}

	if "`e'" == "fluencyofideas" {
		local title "Fluency of ideas"
	}

	if "`e'" == "grossbodycoordination" {
		local title "Gross body coordination"
	}

	if "`e'" == "hearingsensitivity" {
		local title "Hearing sensitivity"
	}

	if "`e'" == "inductivereasoning" {
		local title "Inductive reasoning"
	}

	if "`e'" == "informationordering" {
		local title "Information ordering"
	}

	if "`e'" == "mathematicalreasoning" {
		local title "Mathematical reasoning"
	}

	if "`e'" == "memorization" {
		local title "Memorization"
	}

	if "`e'" == "nearvision" {
		local title "Near vision"
	}

	if "`e'" == "numberfacility" {
		local title "Number facility"
	}

	if "`e'" == "oralcomprehension" {
		local title "Oral comprehension"
	}

	if "`e'" == "oralexpression" {
		local title "Oral expression"
	}

	if "`e'" == "originality" {
		local title "Originality"
	}

	if "`e'" == "perceptualspeed" {
		local title "Perceptual speed"
	}

	if "`e'" == "problemsensitivity" {
		local title "Problem sensitivity"
	}

	if "`e'" == "responseorientation" {
		local title "Response orientation"
	}

	if "`e'" == "selectiveattention" {
		local title "Selective attention"
	}

	if "`e'" == "spatialorientation" {
		local title "Spatial orientation"
	}

	if "`e'" == "speechclarity" {
		local title "Speech clarity"
	}

	if "`e'" == "speechrecognition" {
		local title "Speech recognition"
	}

	if "`e'" == "speedofclosure" {
		local title "Speed of closure"
	}

	if "`e'" == "speedoflimbmovement" {
		local title "Speed of limb movement"
	}

	if "`e'" == "stamina" {
		local title "Stamina"
	}

	if "`e'" == "staticstrength" {
		local title "Static strength"
	}

	if "`e'" == "timesharing" {
		local title "Time sharing"
	}

	if "`e'" == "visualcolordis" {
		local title "Visual color discrimination"
	}

	if "`e'" == "visualization" {
		local title "Visualization"
	}

	if "`e'" == "writtencomprehension" {
		local title "Written comprehension"
	}

	if "`e'" == "writtenexpression" {
		local title "Written expression"
		
	}	
		label var scalar "`title'"
		di "`e'"
		di "`title'"
		qui reg scalar ib1.(${`e'}) if onet_element == "`e'", nocons
		outreg2 using "${output}\Tables10_15.xls", ctitle("`title'") dec(3) label
		qui reg scalar ib1.(${`e'}) if onet_element == "`e'", nocons

		predict y_hat_`e'
		replace y_hat = y_hat_`e' if onet_element == "`e'"
		
		
		matrix Tab_`e' = r(table)
		matrix e = J(1,rowsof(Tab_`e'),0)
		matrix e[1,1] = 1
		matrix B_`e' =   e * Tab_`e'
		matrix B_`e' = B_`e''  // trasponowanie
	 
	// "missing" coefficients for base categories are set to 0, to not chagne prediction
			forvalues i = 1/`=rowsof(B_`e')' {
				forvalues j = 1/`=colsof(B_`e')' {
					if missing(B_`e'[`i', `j']) {
						matrix B_`e'[`i', `j'] = 0
					}
				}
			}

	local rows_B_`e' : rownames B_`e'
	local rows_no: word count `rows_B_`e''
	local seed_predict ""
	forval k=1/`rows_no'{
		local varname: word `k' of  `rows_B_`e''
		local coeff= el(B_`e',`k',1)
		local predict_line "`varname' * `coeff'"
		local seed_predict "`seed_predict' `predict_line' +"
	}
	local seed_predict "`seed_predict' 0"

	global bv_`e' "`seed_predict'"

	gen el_`e' = `seed_predict' if onet_element == "`e'"
		
	}

	egen y_hat_ability = mean(y_hat) ,by(onet_element isco2d)

	merge m:1 isco08_2d using "${data_source}\\felten\ability_base_isco_2d.dta"
	keep if _merge == 3
	drop _merge

	merge m:1 onet_element using "${data_source}\\felten\_binary_all"
	drop _merge v*

	keep isco08_2d scalar y_hat_ability   ability_base onet_element onet_score
	duplicates drop

	corr scalar y_hat_ability

	egen ability_base_check = total(scalar) , by(isco08_2d) 
	su ability_base_check ability_base
	drop ability_base_check

	gen impact_felten = scalar * onet_score
	egen total_weighted_impact_felten=sum(impact_felten), by(isco08_2d)

	gen impact_piaac = y_hat_ability * onet_score
	egen total_weighted_impact_piaac=sum(impact_piaac), by(isco08_2d)

	keep isco08_2d ability_base total_weighted_impact_felten  total_weighted_impact_piaac  

	duplicates drop

	gen impact_felten = total_weighted_impact_felten / ability_base
	gen impact_piaac = total_weighted_impact_piaac / ability_base

	egen aioe_felten = std(impact_felten)
	egen aioe_piaac = std(impact_piaac)

	merge 1:1 isco08_2d using "${data_source}\\felten\AIOE_Felten_isco_2d.dta", keepus(aioe_isco_2d)
	keep if _merge == 3
	drop _merge
	ren aioe_isco_2d aioe

	keep isco08_2d aioe aioe_piaac 
	label var aioe_piaac "AIOE calculated on PIAAC"
	label var aioe "AIOE Felten et al. (2021)"
	gen country = "United States"



********************************************************************************
********************************************************************************
********************************************************************************
//Figure 1
********************************************************************************
********************************************************************************
*******************************************************************************

	gen label = ""

	replace label = "Chief Executives, Senior Officials and Legislators" if isco08_2d == 11
	replace label = "Administrative and Commercial Managers" if isco08_2d == 12
	replace label = "Production and Specialized Services Managers" if isco08_2d == 13
	replace label = "Hospitality, Retail and Other Services Managers" if isco08_2d == 14

	replace label = "Science and Engineering Professionals" if isco08_2d == 21
	replace label = "Health Professionals" if isco08_2d == 22
	replace label = "Teaching Professionals" if isco08_2d == 23
	replace label = "Business and Administration Professionals" if isco08_2d == 24
	replace label = "Information and Communications Technology Professionals" if isco08_2d == 25
	replace label = "Legal, Social and Cultural Professionals" if isco08_2d == 26

	replace label = "Science and Engineering Associate Professionals" if isco08_2d == 31
	replace label = "Health Associate Professionals" if isco08_2d == 32
	replace label = "Business and Administration Associate Professionals" if isco08_2d == 33
	replace label = "Legal, Social, Cultural and Related Associate Professionals" if isco08_2d == 34
	replace label = "Information and Communications Technicians" if isco08_2d == 35

	replace label = "General and Keyboard Clerks" if isco08_2d == 41 
	replace label = "Customer Services Clerks" if isco08_2d == 42
	replace label = "Numerical and Material Recording Clerks" if isco08_2d == 43
	replace label = "Other Clerical Support Workers" if isco08_2d == 44

	replace label = "Personal Services Workers" if isco08_2d == 51 
	replace label = "Sales Workers" if isco08_2d == 52
	replace label = "Personal Care Workers" if isco08_2d == 53
	replace label = "Protective Services Workers" if isco08_2d == 54

	replace label = "Market-oriented Skilled Agricultural Workers" if isco08_2d == 61 
	replace label = "Market-oriented Skilled Forestry, Fishery and Hunting Workers" if isco08_2d == 62

	replace label = "Building and Related Trades Workers (excluding Electricians)" if isco08_2d == 71 
	replace label = "Metal, Machinery and Related Trades Workers" if isco08_2d == 72
	replace label = "Handicraft and Printing Workers" if isco08_2d == 73
	replace label = "Electrical and Electronic Trades Workers" if isco08_2d == 74
	replace label = "Food Processing, Woodworking, Garment and Other Craft and Related Trades Workers" if isco08_2d == 75

	replace label = "Stationary Plant and Machine Operators" if isco08_2d == 81 
	replace label = "Assemblers" if isco08_2d == 82
	replace label = "Drivers and Mobile Plant Operators" if isco08_2d == 83

	replace label = "Cleaners and Helpers" if isco08_2d == 91 
	replace label = "Agricultural, Forestry and Fishery Labourers" if isco08_2d == 92
	replace label = "Labourers in Mining, Construction, Manufacturing and Transport" if isco08_2d == 93
	replace label = "Food Preparation Assistants" if isco08_2d == 94
	replace label = "Street and Related Sales and Services Workers" if isco08_2d == 95
	replace label = "Refuse Workers and Other Elementary Workers" if isco08_2d == 96

	gen label1=""
	replace label1=label if isco08_2d == 22 | isco08_2d == 95 | isco08_2d == 53 | isco08_2d == 91 | isco08_2d == 94 

	cap drop label_l label_r label_b label_t
	gen label_l = label if isco08_2d == 22 | isco08_2d == 21 |isco08_2d == 95  //| isco08_2d == 31 
	gen label_r = label if isco08_2d == 44 | isco08_2d == 53 | isco08_2d == 75 | isco08_2d == 91 | isco08_2d == 94 | isco08_2d == 31
	gen label_b = label if isco08_2d == 52 
	gen label_t = label if isco08_2d == 31 
	local color1 "182 22 58%30"
	local color2 "182 22 58"
	local color3 "182 22 58"
	pwcorr aioe aioe_piaac
	twoway scatter aioe aioe_piaac if isco08_2d != 44 | isco08_2d != 52 | isco08_2d != 53 | isco08_2d != 75 | isco08_2d != 91 | isco08_2d != 94 | isco08_2d != 31 , mc("`color1'") mlc("`color2'")  mlabc("`color2'")   mlabel(label_l) mlabsize(vsmall) mlabpos(11) ///
	|| scatter aioe aioe_piaac if   isco08_2d == 53 | isco08_2d == 75 | isco08_2d == 91 | isco08_2d == 94  , mlabel(label_r) mlabsize(vsmall) mlabpos(3) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| scatter aioe aioe_piaac if  isco08_2d == 44 , mlabel(label_r) mlabsize(vsmall) mlabpos(2) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| scatter aioe aioe_piaac if  isco08_2d == 52 ,  mlabel(label_b) mlabsize(vsmall) mlabpos(6) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| scatter aioe aioe_piaac if  isco08_2d == 31 ,  mlabel(label_t) mlabsize(vsmall) mlabpos(12) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| lfit aioe aioe_piaac, title("Correlation 91%") lc("`color3'") ///
	|| function y=x , range(-2 3) lp(dash) lw(vthin) lc(black) ///
	, xline(0,lp(shortdash) lw(vvvthin) lc(grey)) yline(0,lp(shortdash) lw(vvvthin) lc(grey)) legend(order(6 "Fitted values" 7 "y=x , 45 degree line")) ///
	xtitle("Country-specific AI exposure (PIAAC-based)") ytitle("Felten et al. (2021) AI-exposure") graphregion(margin(zero))

	graph export "${output}\Figure_S1.png", as(png) replace  
	graph export "${output}\Figure_S1.emf", as(emf) replace  
	
	
	
	
********************************************************************************	
********************************************************************************
********************************************************************************
// Figure S2
********************************************************************************	
********************************************************************************
********************************************************************************

	merge 1:1 isco08_2d using "C:\Users\karol.madon\OneDrive - IBS\World Bank\AI_piaac\codes\replication_package_2026_05_09\submission_replication\data\felten\Eloundou_GPT_exposure_isco2d.dta", keepus(human_beta_std)

	replace label1=label if isco08_2d == 22 | isco08_2d == 95 | isco08_2d == 53 | isco08_2d == 91 | isco08_2d == 94 

	cap drop label_l label_r label_b label_t
	gen label_l = label if isco08_2d == 22 | isco08_2d == 21 |isco08_2d == 95  //| isco08_2d == 31 
	gen label_r = label if isco08_2d == 44 | isco08_2d == 53 | isco08_2d == 75 | isco08_2d == 91 | isco08_2d == 94 | isco08_2d == 31
	gen label_b = label if isco08_2d == 52 
	gen label_t = label if isco08_2d == 31 

	local color1 "182 22 58%30"
	local color2 "182 22 58"
	local color3 "182 22 58"
	pwcorr human_beta_std aioe_piaac
		
	twoway scatter human_beta_std aioe_piaac if isco08_2d != 44 | isco08_2d != 52 | isco08_2d != 53 | isco08_2d != 75 | isco08_2d != 91 | isco08_2d != 94 | isco08_2d != 31 , mc("`color1'") mlc("`color2'")  mlabc("`color2'")   mlabel(label_l) mlabsize(vsmall) mlabpos(11) ///
	|| scatter human_beta_std aioe_piaac if   isco08_2d == 53 | isco08_2d == 75 | isco08_2d == 91 | isco08_2d == 94  , mlabel(label_r) mlabsize(vsmall) mlabpos(3) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| scatter human_beta_std aioe_piaac if  isco08_2d == 44 , mlabel(label_r) mlabsize(vsmall) mlabpos(2) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| scatter human_beta_std aioe_piaac if  isco08_2d == 52 ,  mlabel(label_b) mlabsize(vsmall) mlabpos(6) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| scatter human_beta_std aioe_piaac if  isco08_2d == 31 ,  mlabel(label_t) mlabsize(vsmall) mlabpos(12) mlabc("`color2'") mc("`color1'") mlc("`color2'") ///
	|| lfit human_beta_std aioe_piaac, title("Correlation 92%") lc("`color3'") ///
	|| function y=x , range(-2 3) lp(dash) lw(vthin) lc(black) ///
	, xline(0,lp(shortdash) lw(vvvthin) lc(grey)) yline(0,lp(shortdash) lw(vvvthin) lc(grey)) legend(order(6 "Fitted values" 7 "y=x , 45 degree line")) ///
	xtitle("Country-specific AI exposure (PIAAC-based)") ytitle("Eloundou et al. (2024) AI-exposure") graphregion(margin(zero))

	graph export "${output}\Figure_S2.png", as(png) replace  
	graph export "${output}\Figure_S2.emf", as(emf) replace  
	
	
