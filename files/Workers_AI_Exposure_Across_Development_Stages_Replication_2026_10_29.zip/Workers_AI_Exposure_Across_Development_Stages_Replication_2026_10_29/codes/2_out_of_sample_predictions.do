// THis do-file produces:
//	Table S9 
//	Figure S9
//	Figure 1



use "${data_source}\\out_of_sample_prediction.dta", clear


// Set variables for out-of-sample predictions
	global varlist_i1 ln_gdp_pc_t c.ln_gdp_pc_t#c.ln_gdp_pc_t  cycle2 internet_use_t tech_infra pop1564_t ict_import_t //7
	global varlist_i2 ln_gdp_pc_t cycle2 compulsory_edu_t elec_t uni_enr_t //5
	global varlist_i3 ln_gdp_pc_t cycle2 i_hlos_t pop1564_t uni_enr_t ict_development internet_use_t  //7
	global varlist_i4 ln_gdp_pc_t cycle2 ict_import_t fdi_t i_amrt_t dri_score uni_enr_t  //7
	global varlist_i5 ln_gdp_pc_t cycle2 tech_infra  i_amrt_t gvcf_sh urbanisation_t  pop1564_t //7
	global varlist_i7 ln_gdp_pc_t cycle2  elec_t internet_use_t urbanisation_t dri_score //6
	global varlist_i8 ln_gdp_pc_t c.ln_gdp_pc_t#c.ln_gdp_pc_t cycle2 internet_use_t gvcb_sh pop1564_t ict_development dri_score   //8
	global varlist_i9 ln_gdp_pc_t cycle2 tech_infra  i_amrt_t gvcf_sh pop1564_t urbanisation_t //7

********************************************************************************
********************************************************************************
********************************************************************************
// Table S9
********************************************************************************
********************************************************************************
********************************************************************************

		foreach i in  1 2 3 4 5 7 8 9 { 

		if `i'==1{
			local title "Managers (ISCO 1)"
		}
		if `i'==2{
			local title "Professionals (ISCO 2)"
		}
		if `i'==3{
			local title "Technicians (ISCO 3)"
		}
		if `i'==4{
			local title "Clerical workers (ISCO 4)"
		}
		if `i'==5{
			local title "Sales and services workers (ISCO 5)"
		}
		if `i'==7{
			local title "Craftsmen (ISCO 7)"
		}
		if `i'==8{
			local title "Machine operators (ISCO 8)"
		}
		if `i'==9{
			local title "Elementary occupations (ISCO 9)"
		}

		reg ai_exp_isco1d_t ${varlist_i`i'} if isco08_1d==`i' & isco08_2d==`i'1
		outreg2 using "${output}\\Table_S9.xls", excel append dec(3) ctitle("`title'") label sortvar(ln_gdp_pc_t c.ln_gdp_pc_t#c.ln_gdp_pc_t cycle2 compulsory_edu_t i_hlos_t uni_enr_t i_amrt_t pop1564_t elec_t urbanisation_t ict_development dri_score internet_use_t tech_infra fdi_t gvcf_sh gvcb_sh ict_import_t)
		}

********************************************************************************
********************************************************************************
********************************************************************************		
// Figure S9	
********************************************************************************
********************************************************************************
********************************************************************************	

	foreach i in  1 2 3 4 5 7 8 9 { 

	if `i'==1{
		local title "Managers (ISCO 1)"
	}
	if `i'==2{
		local title "Professionals (ISCO 2)"
	}
	if `i'==3{
		local title "Technicians (ISCO 3)"
	}
	if `i'==4{
		local title "Clerical workers (ISCO 4)"
	}
	if `i'==5{
		local title "Sales and services workers (ISCO 5)"
	}
	if `i'==7{
		local title "Craftsmen (ISCO 7)"
	}
	if `i'==8{
		local title "Machine operators (ISCO 8)"
	}
	if `i'==9{
		local title "Elementary occupations (ISCO 9)"
	}


	reg ai_exp_isco1d_t ${varlist_i`i'} if isco08_1d==`i' & isco08_2d==`i'1

	cap drop y_hat_i`i'_1 ai_ols_i`i'_1
	predict y_hat_i`i'_1 
	gen ai_ols_i`i'_1 = ai_exp_isco1d_t if isco08_1d == `i'
	replace ai_ols_i`i'_1= y_hat_i`i'_1 if mi(ai_exp_isco1d_t) & isco08_1d == `i' 
	format  ai_ols_i*  %6.1f  
	cap format impact_felten_std %6.1f  

	if `i' < 10 {
		local legend `" order(1 "Survey" 3 "Prediction") "'
		local legend "off" 
		}
				local color1 "180 22 58%90"
				local color2 "black*0.25%90"
				local color3 "180 22 58*.6%90"
				
	// right panel (Lewandowski et al. 2025)			
					twoway scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code!="US", mlabel(country_code) mfcolor("`color1'") mlcolor(none) mlabc("`color1'") ///
					|| qfit ai_ols_i`i'_1 ln_gdp_pc_t if  isco08_1d==`i' & isco08_2d == `i'1 & flag == 0, lc("`color1'") ///
					|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color3'") mlcolor(none) mlabc("`color3'") ///
					|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
					|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code=="US", mlabel(country_code) mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) ///
					|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code=="US", mlabel(country_code) mfcolor("red*.7") mlcolor(none) mlabc("red*.7") msymbol(diamond) msiz(medlarge) ///
					 legend(`legend') title("Country-specific AI exposures",size(large)) xtitle("log GDP per capita",size(med)) ytitle("The average AI exposure ",size(med)) name(isco_`i', replace) ylabel(-1.8(0.4)1.4, nogrid labsize(med)) xlabel(,labsize(med)) graphregion(margin(zero)) yline(0,lp(dash) lw(vvvthin) lc(black))

	// left panel (Felten et al. 2021)
		
					twoway scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code!="US", mlabel(country_code) mfcolor("`color1'") mlcolor(none) mlabc("`color1'") ///
					|| qfit ai_exp_felten_isco1d_t ln_gdp_pc_t if  isco08_1d==`i' & isco08_2d == `i'1 & flag == 0, lc("`color1'") ///
					|| scatter ai_exp_felten_isco1d_t  ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color3'") mlcolor(none) mlabc("`color3'") ///
					|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & country_code=="XXX" & flag == 0 & cycle2==1, mlabel(country_code) mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
					|| scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code=="US", mlabel(country_code) mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) ///
					|| scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code=="US", mlabel(country_code) mfcolor("red*.7") mlcolor(none) mlabc("red*.7") msymbol(diamond) msiz(medlarge) ///
					legend(`legend') title("AIOE Felten et al. (2021)",size(large)) xtitle("log GDP per capita",size(med)) ytitle("The average AI exposure",size(med)) name(felten_isco_`i', replace) ylabel(-1.8(0.4)1.4, nogrid labsize(med)) xlabel(,labsize(med)) graphregion(margin(zero)) yline(0,lp(dash) lw(vvvthin) lc(black))
		
					 }	
				 
	cap mkdir "${output}\\Figure_S9"				 
	foreach i in 1 2 3 4 5 7 8 9{
		di `i'

	graph combine felten_isco_`i' isco_`i' , graphregion(color(white) margin(zero)) cols(2) ycommon xcommon 
	graph save "Graph" "${output}\\Figure_S9\isco_`i'.gph", replace

	graph export "${output}\\Figure_S9\isco_`i'.png", as(png) replace width(1920) height(1080)	
	graph display, xsize(3.2) ysize(1.8)						
	graph export "${output}\\Figure_S9\isco_`i'.emf", as(emf) replace  
	}				 
		
		

	
********************************************************************************
********************************************************************************
********************************************************************************		
// Figure 1	
********************************************************************************
********************************************************************************
********************************************************************************
	
local legend off				 
local yscale "-1.8(0.4)1.1"
			local i 1 
			local i3 8
			
			local color1 "180 22 58%90"
			local color2 "black*0.25%90"
			local color3 "180 22 58*.6%90"
				twoway scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code!="US", mlabel(country_code) mfcolor("`color1'") mlcolor(none) mlabc("`color1'") ///
				|| qfit ai_ols_i`i'_1 ln_gdp_pc_t if  isco08_1d==`i' & isco08_2d == `i'1 & flag == 0, lc("`color1'") ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color3'") mlcolor(none) mlabc("`color3'") ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code=="US", mlabel(country_code) mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code=="US", mlabel(country_code) mfcolor("red*.7") mlcolor(none) mlabc("red*.7") msymbol(diamond) msiz(medlarge) ///
				|| scatter ai_ols_i`i3'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==0 & country_code!="US", mlabel(country_code) mfcolor("`color1'") mlcolor(none) msymbol(triangle) mlabc("`color1'") ///				
				|| qfit ai_ols_i`i3'_1 ln_gdp_pc_t if  isco08_1d==`i3' & isco08_2d == `i3'1 & flag == 0, lc("`color1'") ///
				|| scatter ai_ols_i`i3'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color3'") mlcolor(none) msymbol(triangle) mlabc("`color3'") ///
				|| scatter ai_ols_i`i3'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color2'") mlcolor(none) msymbol(triangle) mlabc("`color2'")  ///
				|| scatter ai_ols_i`i3'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==0 & country_code=="US", mlabel(country_code) mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) ///
				|| scatter ai_ols_i`i3'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==1 & country_code=="US", mlabel(country_code) mfcolor("red*.7") mlcolor(none) mlabc("red*.7") msymbol(diamond) msiz(medlarge) ///												
				legend(`legend') title("Country-specific AI exposures",size(large)) xtitle("log GDP per capita",size(med)) ytitle("The average AI exposure ",size(med)) name(piaac, replace) ylabel(`yscale', nogrid labsize(med)) xlabel(,labsize(med)) graphregion(margin(zero)) yline(0,lp(dash) lw(vvvthin) lc(black))
		
				twoway scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code!="US", mlabel(country_code) mfcolor("`color1'") mlcolor(none) mlabc("`color1'") ///
				|| qfit ai_exp_felten_isco1d_t ln_gdp_pc_t if  isco08_1d==`i' & isco08_2d == `i'1 & flag == 0, lc("`color1'") ///
				|| scatter ai_exp_felten_isco1d_t  ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color3'") mlcolor(none) mlabc("`color3'") ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & country_code=="XXX" & flag == 0 & cycle2==1, mlabel(country_code) mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
				|| scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0 & country_code=="US", mlabel(country_code) mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) ///
				|| scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1 & country_code=="US", mlabel(country_code) mfcolor("red*.7") mlcolor(none) mlabc("red*.7") msymbol(diamond) msiz(medlarge) ///
				|| scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==0 & country_code!="US", mlabel(country_code) mfcolor("`color1'") mlcolor(none) msymbol(triangle) mlabc("`color1'") ///				
				|| qfit ai_exp_felten_isco1d_t ln_gdp_pc_t if  isco08_1d==`i3' & isco08_2d == `i3'1 & flag == 0, lc("`color1'") ///
				|| scatter ai_exp_felten_isco1d_t  ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==1 & country_code!="US", mlabel(country_code) mfcolor("`color3'") mlcolor(none) msymbol(triangle) mlabc("`color3'") ///
				|| scatter ai_ols_i`i3'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i3' & isco08_2d==`i3'1 & country_code=="XXX" & flag == 0 & cycle2==1, mlabel(country_code) mfcolor("`color2'") mlcolor(none) msymbol(triangle) mlabc("`color2'")  ///
				|| scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==0 & country_code=="US", mlabel(country_code) mfcolor("red") mlcolor(none) mlabc("red") msymbol(diamond) msiz(medlarge) ///
				|| scatter ai_exp_felten_isco1d_t ln_gdp_pc_t if source=="survey" & isco08_1d==`i3' & isco08_2d==`i3'1 & flag == 0 & cycle2==1 & country_code=="US", mlabel(country_code) mfcolor("red*.7") mlcolor(none) mlabc("red*.7") msymbol(diamond) msiz(medlarge) ///			
				legend(`legend') title("AIOE Felten et al. (2021)",size(large)) xtitle("log GDP per capita",size(med)) ytitle("The average AI exposure",size(med)) name(felten, replace) ylabel(`yscale', nogrid labsize(med)) xlabel(,labsize(med)) graphregion(margin(zero)) yline(0,lp(dash) lw(vvvthin) lc(black))

								 
				 
				 
		graph combine felten piaac , graphregion(color(white) margin(zero)) cols(2) ycommon xcommon 
		graph export "${output}\\Figure_1.emf", as(emf) replace  
		graph export "${output}\\Figure_1.png", as(png) replace  
	


//LEGEND Figure 1

local i 1
			local color1 "180 22 58%90"
			local color2 "black*0.25%90"
			local color3 "180 22 58*.6%90"
				twoway scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==0, mlabel(country_code) mfcolor("`color1'") mlcolor(none) msymbol(square) mlabc("`color1'") ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="survey" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0 & cycle2==1, mlabel(country_code) mfcolor("`color3'") mlcolor(none) msymbol(square) mlabc("`color3'") ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0, mlabel(country_code) mfcolor("`color2'") mlcolor(none) msymbol(square) mlabc("`color2'")  ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0, mlabel(country_code) mfcolor("`color1'") mlcolor(none) mlabc("`color1'")  ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0, mlabel(country_code) mfcolor("`color3'") mlcolor(none) mlabc("`color3'")  ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0, mlabel(country_code) mfcolor("`color2'") mlcolor(none) mlabc("`color2'")  ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0, mlabel(country_code) mfcolor("`color1'") mlcolor(none) msymbol(triangle) mlabc("`color1'")  ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0, mlabel(country_code) mfcolor("`color3'") mlcolor(none) msymbol(triangle) mlabc("`color3'")  ///
				|| scatter ai_ols_i`i'_1 ln_gdp_pc_t if source=="predicted" & isco08_1d==`i' & isco08_2d==`i'1 & flag == 0, mlabel(country_code) mfcolor("`color2'") mlcolor(none) msymbol(triangle) mlabc("`color2'")  ///
				legend(order(1 "Survey 2011-2018" 2 "Survey 2022-2023" 3 "Prediction" 4 "" 5 "" 6 "Managers" 7 "" 8 "" 9 "Plant and machine operators, and assemblers") row(3)) yscale(off) xscale(off) xlabel(none) ylabel(none)  plotregion(lcolor(none) fcolor(none) margin(zero)) graphregion(fcolor(white) lcolor(none)) name(legend, replace)
				graph display, xsize(3.2) ysize(1.8) 					
graph export "${output}\\Figure_1_legend.emf", as(emf) replace  
				 		
		

********************************************************************************
********************************************************************************
********************************************************************************
// Country-specific ISCO08-2d exposures
********************************************************************************
********************************************************************************
********************************************************************************

	foreach i in 1 2 3 4 5 7 8 9 {
		di `i'
	reg ai_exp_isco2d_t ${varlist_i`i'} i.isco08_2d if isco08_1d==`i'  
	predict y_hat2d_i`i' //if gdp_pc >= 8.456019 & gdp_pc <= 11.59435

	gen ai_ols2d_i`i' = ai_exp_isco2d_t if isco08_1d == `i'
	replace ai_ols2d_i`i'= y_hat2d_i`i' if mi(ai_exp_isco2d_t ) & isco08_1d == `i' 
	}


preserve
gen source_isco2d = source
replace source_isco2d = "predicted" if  inlist(country_name, "Austria","Canada","Estonia","Finland","Philippines") & cycle2==0
lab var flag "countires GDP out of survey data range "

gen ai_exp_2d_ =. 
replace ai_exp_2d_ = ai_ols2d_i1 if isco08_1d == 1 
replace ai_exp_2d_ = ai_ols2d_i2 if isco08_1d == 2 
replace ai_exp_2d_ = ai_ols2d_i3 if isco08_1d == 3 
replace ai_exp_2d_ = ai_ols2d_i4 if isco08_1d == 4 
replace ai_exp_2d_ = ai_ols2d_i5 if isco08_1d == 5 
replace ai_exp_2d_ = ai_ols2d_i7 if isco08_1d == 7 	
replace ai_exp_2d_ = ai_ols2d_i8 if isco08_1d == 8 	
replace ai_exp_2d_ = ai_ols2d_i9 if isco08_1d == 9 	

gen ai_exp_1d  = ai_exp_isco1d_t
replace ai_exp_1d = ai_ols_i1_1 if source == "predicted" & isco08_1d == 1 
replace ai_exp_1d = ai_ols_i2_1 if source == "predicted" & isco08_1d == 2 
replace ai_exp_1d = ai_ols_i3_1 if source == "predicted" & isco08_1d == 3 
replace ai_exp_1d = ai_ols_i4_1 if source == "predicted" & isco08_1d == 4 
replace ai_exp_1d = ai_ols_i5_1 if source == "predicted" & isco08_1d == 5 
replace ai_exp_1d = ai_ols_i7_1 if source == "predicted" & isco08_1d == 7 	
replace ai_exp_1d = ai_ols_i8_1 if source == "predicted" & isco08_1d == 8 	
replace ai_exp_1d = ai_ols_i9_1 if source == "predicted" & isco08_1d == 9 	


keep country_code isco08_2d country_name country_code_3d source source_isco2d flag ai_exp_2d_ ai_exp_1d cycle2
ren ai_exp_1d ai_exp_1d_
reshape wide ai_exp_2d_ ai_exp_1d_, i(country_code cycle2) j(isco08_2d)

order country_code country_name country_code_3d cycle2 source source_isco2d flag ai_exp_1d_* ai_exp_2d_*

keep country_code country_name country_code_3d cycle2 source source_isco2d flag ai_exp_2d_* ///
	ai_exp_1d_11 ai_exp_1d_21 ai_exp_1d_31 ai_exp_1d_41 ai_exp_1d_51 ai_exp_1d_71 ai_exp_1d_81 ai_exp_1d_91

	ren (ai_exp_1d_11 ai_exp_1d_21 ai_exp_1d_31 ai_exp_1d_41 ai_exp_1d_51 ai_exp_1d_71 ai_exp_1d_81 ai_exp_1d_91) (	ai_exp_1d_1 ai_exp_1d_2 ai_exp_1d_3 ai_exp_1d_4 ai_exp_1d_5 ai_exp_1d_7 ai_exp_1d_8 ai_exp_1d_9)


save "${output}\\piaac_based_ai_exposures_full_sample_prediction.dta", replace


*label drop cycle2
cap drop time
gen time = "2011-2018" if cycle2==0
replace time = "2022-2023" if cycle2==1
drop cycle2
label variable time "Reference years"

rename source source_isco1d
label var source_isco1d "Data source for ISCO08 1-digit exposures"
label var source_isco2d "Data source for ISCO08 2-digit exposures"
label var country_code "ISO 3166-1 alpha-2"
label var country_code_3d "ISO 3166-1 alpha-3"
label var flag "1- prediction for country which GDP is out of survey data range"

drop flag
order country_name country_code country_code_3d time source_isco1d source_isco2d

* 1-digit major groups
label variable ai_exp_1d_1 "AI exp. ISCO-08 1: Managers"
label variable ai_exp_1d_2 "AI exp. ISCO-08 2: Professionals"
label variable ai_exp_1d_3 "AI exp. ISCO-08 3: Technicians & assoc. prof."
label variable ai_exp_1d_4 "AI exp. ISCO-08 4: Clerical support workers"
label variable ai_exp_1d_5 "AI exp. ISCO-08 5: Service and sales workers"
label variable ai_exp_1d_7 "AI exp. ISCO-08 7: Craft & trades workers"
label variable ai_exp_1d_8 "AI exp. ISCO-08 8: Plant & machine operators"
label variable ai_exp_1d_9 "AI exp. ISCO-08 9: Elementary occupations"

* 2-digit sub-major groups
label variable ai_exp_2d_11 "AI exp. ISCO-08 11: Chief exec. & sr. officials"
label variable ai_exp_2d_12 "AI exp. ISCO-08 12: Admin. & commercial managers"
label variable ai_exp_2d_13 "AI exp. ISCO-08 13: Production & spec. managers"
label variable ai_exp_2d_14 "AI exp. ISCO-08 14: Hospitality & retail managers"
label variable ai_exp_2d_21 "AI exp. ISCO-08 21: Science & engineering prof."
label variable ai_exp_2d_22 "AI exp. ISCO-08 22: Health professionals"
label variable ai_exp_2d_23 "AI exp. ISCO-08 23: Teaching professionals"
label variable ai_exp_2d_24 "AI exp. ISCO-08 24: Business & admin. prof."
label variable ai_exp_2d_25 "AI exp. ISCO-08 25: ICT professionals"
label variable ai_exp_2d_26 "AI exp. ISCO-08 26: Legal, social & cultural prof."
label variable ai_exp_2d_31 "AI exp. ISCO-08 31: Science & eng. assoc. prof."
label variable ai_exp_2d_32 "AI exp. ISCO-08 32: Health assoc. professionals"
label variable ai_exp_2d_33 "AI exp. ISCO-08 33: Business & admin. assoc. prof."
label variable ai_exp_2d_34 "AI exp. ISCO-08 34: Legal, social & cultural assoc."
label variable ai_exp_2d_35 "AI exp. ISCO-08 35: ICT technicians"
label variable ai_exp_2d_41 "AI exp. ISCO-08 41: General & keyboard clerks"
label variable ai_exp_2d_42 "AI exp. ISCO-08 42: Customer services clerks"
label variable ai_exp_2d_43 "AI exp. ISCO-08 43: Numerical & material rec. clerks"
label variable ai_exp_2d_44 "AI exp. ISCO-08 44: Other clerical support workers"
label variable ai_exp_2d_51 "AI exp. ISCO-08 51: Personal service workers"
label variable ai_exp_2d_52 "AI exp. ISCO-08 52: Sales workers"
label variable ai_exp_2d_53 "AI exp. ISCO-08 53: Personal care workers"
label variable ai_exp_2d_54 "AI exp. ISCO-08 54: Protective services workers"
label variable ai_exp_2d_71 "AI exp. ISCO-08 71: Building & trades workers"
label variable ai_exp_2d_72 "AI exp. ISCO-08 72: Metal & machinery trades"
label variable ai_exp_2d_73 "AI exp. ISCO-08 73: Handicraft & printing workers"
label variable ai_exp_2d_74 "AI exp. ISCO-08 74: Electrical & electronics trades"
label variable ai_exp_2d_75 "AI exp. ISCO-08 75: Food, wood & garment workers"
label variable ai_exp_2d_81 "AI exp. ISCO-08 81: Stationary plant operators"
label variable ai_exp_2d_82 "AI exp. ISCO-08 82: Assemblers"
label variable ai_exp_2d_83 "AI exp. ISCO-08 83: Drivers & mobile plant operators"
label variable ai_exp_2d_91 "AI exp. ISCO-08 91: Cleaners and helpers"
label variable ai_exp_2d_92 "AI exp. ISCO-08 92: Agricultural laborers"
label variable ai_exp_2d_93 "AI exp. ISCO-08 93: Laborers in mining & constr."
label variable ai_exp_2d_94 "AI exp. ISCO-08 94: Food preparation assistants"
label variable ai_exp_2d_95 "AI exp. ISCO-08 95: Street sales & service workers"
label variable ai_exp_2d_96 "AI exp. ISCO-08 96: Refuse & elementary workers"

save "${output}\\Lewandowski_et_al_2025_AI_exposures.dta", replace


restore






		
		
		
		
		
		